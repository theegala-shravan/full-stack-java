document.addEventListener('DOMContentLoaded', () => {
    // Function to handle adding animation classes
    const handleAnimation = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                observer.unobserve(entry.target);
            }
        });
    };

    // Create an IntersectionObserver instance
    const observer = new IntersectionObserver(handleAnimation, {
        threshold: 0.1
    });

    // Target elements for animation
    const elements = document.querySelectorAll('.animate');
    elements.forEach(el => observer.observe(el));
});
