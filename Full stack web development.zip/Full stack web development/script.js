document.addEventListener("DOMContentLoaded", () => {
  // Select all elements that open popups
  const openPopupLinks = document.querySelectorAll(".openPopup");
  // Select all popup elements
  const popups = document.querySelectorAll(".popup");
  // Select all close buttons
  const closeButtons = document.querySelectorAll(".close");
  // Select navigation buttons
  const prevButton = document.getElementById("prev");
  const nextButton = document.getElementById("next");

  // Show a popup
  const showPopup = (popup) => {
    popup.style.display = "flex";
  };

  // Hide a popup
  const hidePopup = (popup) => {
    popup.style.display = "none";
  };

  // Open the correct popup
  openPopupLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      const targetId = link.getAttribute("data-target");
      const targetPopup = document.getElementById(targetId);
      if (targetPopup) {
        showPopup(targetPopup);
      } else {
        console.error(`Popup with ID ${targetId} not found.`);
      }
    });
  });

  // Close popups using the close button
  closeButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const popup = button.closest(".popup");
      if (popup) {
        hidePopup(popup);
      }
    });
  });

  // Close popups when clicking outside the popup content
  window.addEventListener("click", (event) => {
    if (event.target.classList.contains("popup")) {
      hidePopup(event.target);
    }
  });

  // Project navigation functionality
  let currentProjectIndex = 0;
  const projectItems = document.querySelectorAll(".project-item");

  const showProject = (index) => {
    projectItems.forEach((item, i) => {
      item.style.display = i === index ? "block" : "none";
    });
  };

  // Show the current project
  showProject(currentProjectIndex);

  // Navigate to the previous project
  if (prevButton) {
    prevButton.addEventListener("click", () => {
      if (currentProjectIndex > 0) {
        currentProjectIndex--;
        showProject(currentProjectIndex);
      }
    });
  }

  // Navigate to the next project
  if (nextButton) {
    nextButton.addEventListener("click", () => {
      if (currentProjectIndex < projectItems.length - 1) {
        currentProjectIndex++;
        showProject(currentProjectIndex);
      }
    });
  }
});
